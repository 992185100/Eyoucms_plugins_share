DROP TABLE IF EXISTS `#@__weapp_ask`;
DROP TABLE IF EXISTS `#@__weapp_ask_answer`;
DROP TABLE IF EXISTS `#@__weapp_ask_answer_like`;
DROP TABLE IF EXISTS `#@__weapp_ask_type`;