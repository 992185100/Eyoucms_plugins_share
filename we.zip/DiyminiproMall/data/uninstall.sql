DROP TABLE IF EXISTS `#@__weapp_diyminipro_mall`;
DROP TABLE IF EXISTS `#@__weapp_diyminipro_mall_page`;
DROP TABLE IF EXISTS `#@__weapp_diyminipro_mall_setting`;
DROP TABLE IF EXISTS `#@__weapp_diyminipro_mall_users`;