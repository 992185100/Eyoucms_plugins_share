/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : eyoucms_develop

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2018-07-14 16:08:17
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for #@__weapp_wx_config
-- ----------------------------
DROP TABLE IF EXISTS `#@__weapp_wx_config`;

-- ----------------------------
-- Table structure for #@__weapp_wx_img
-- ----------------------------
DROP TABLE IF EXISTS `#@__weapp_wx_img`;

-- ----------------------------
-- Table structure for #@__weapp_wx_keyword
-- ----------------------------
DROP TABLE IF EXISTS `#@__weapp_wx_keyword`;

-- ----------------------------
-- Table structure for #@__weapp_wx_menu
-- ----------------------------
DROP TABLE IF EXISTS `#@__weapp_wx_menu`;

-- ----------------------------
-- Table structure for #@__weapp_wx_news
-- ----------------------------
DROP TABLE IF EXISTS `#@__weapp_wx_news`;

-- ----------------------------
-- Table structure for #@__weapp_wx_pic
-- ----------------------------
DROP TABLE IF EXISTS `#@__weapp_wx_pic`;

-- ----------------------------
-- Table structure for #@__weapp_wx_subscribe
-- ----------------------------
DROP TABLE IF EXISTS `#@__weapp_wx_subscribe`;

-- ----------------------------
-- Table structure for #@__weapp_wx_text
-- ----------------------------
DROP TABLE IF EXISTS `#@__weapp_wx_text`;